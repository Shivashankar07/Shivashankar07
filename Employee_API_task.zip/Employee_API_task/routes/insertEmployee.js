const express = require("express");
const conn = require("../connection");
const reader = require("xlsx");
const fs = require("fs");
const Router = express.Router();
const upload = require("express-fileupload");

Router.post("/insertEmployee", (req, res) => {
  if (req.files) {
    var fileUpd = req.files.fileUpload;
    var filename = fileUpd.name;
    var docCheck = filename.split(".");

    if (docCheck[1] == "csv" || docCheck[1] == "xlsx") {
      fileUpd.mv("../uploads/" + filename, function (err) {
        if (err) {
          res.send("err", err);
        } else {
          // Reading our file
          const file = reader.readFile("../uploads/" + filename, {
            cellDates: true,
          });
          let data = [];
          const sheets = file.SheetNames;
          // reading sheets in excel
          for (let i = 0; i < sheets.length; i++) {
            const temp = reader.utils.sheet_to_json(
              file.Sheets[file.SheetNames[i]]
            );
            temp.forEach((res) => {
              data.push(res);
            });
          }

          fs.unlink("../uploads/" + filename, (err) => {
            if (err) {
              console.log(err);
            }
          });

          if (data.length > 1) {
            for (var i in data) {
              var eName = data[i]["Employee name"];
              var empEmail = data[i]["Email"];
              var doj = data[i]["Date of join"];

              if (!eName) {
                res.send({
                  status: 500,
                  message: data[i],
                  errorMsg: "Please enter the employee name",
                });
              } else if (!empEmail) {
                res.send({
                  status: 500,
                  message: "",
                  errorMsg: "Please enter the email address",
                });
              } else if (!doj) {
                res.send({
                  status: 500,
                  message: "",
                  errorMsg: "Please enter the date of join",
                });
              } else {
                var pwd = generatePassword(8);
                res.send(pwd);
                // for(var i in data)
                // {
                //     var sql =
                //     "INSERT INTO emp_details (emp_id, emp_name, emp_email, emp_doj, emp_password, emp_createdon, emp_updatedon) VALUES ('',"+eName+","+empEmail+","+doj+",)";
                //     con.query(sql, function (err, result) {
                //     if (err) throw err;
                //     console.log("1 record inserted");
                //   });

                // }

                //   res.send({
                //     data,
                //   });
              }
            }
          } else {
            res.send({
              status: 500,
              message: "",
              errorMsg: "There are no employee data in the document",
            });
          }

          // Printing data
          // res.send(data);
        }
      });
    } else {
      res.send({
        status: 500,
        message: "",
        errorMsg: "unsupported file format, please upload csv or excel file",
      });
    }
  } else {
    res.send({
      status: 500,
      message: "",
      errorMsg: "Please upload the document",
    });
  }
});

function generatePassword(passwordLength) {
  var numberChars = "0123456789";
  var upperChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  var lowerChars = "abcdefghijklmnopqrstuvwxyz";
  var allChars = numberChars + upperChars + lowerChars;
  var randPasswordArray = Array(passwordLength);
  randPasswordArray[0] = numberChars;
  randPasswordArray[1] = upperChars;
  randPasswordArray[2] = lowerChars;
  randPasswordArray = randPasswordArray.fill(allChars, 3);
  return shuffleArray(
    randPasswordArray.map(function (x) {
      return x[Math.floor(Math.random() * x.length)];
    })
  ).join("");
}

function shuffleArray(array) {
  for (var i = array.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
  return array;
}

module.exports = Router;
