const express = require("express");

const Router = express.Router();

const conn = require("../connection");

Router.delete("/", (req, res) => {
  var empId = req.body.id;
  var superUser = req.body.superUser;
  if (superUser == 1) {
    if (!empId) {
      res.send({
        status: 500,
        message: "",
        errorMsg: "Please enter a valid employee ID ",
      });
    }
    conn.query(
      "DELETE from emp_details WHERE emp_id =" + empId,
      (err, rows, fields) => {
        if (err) {
          console.log(err);
        } else {
          if (rows.affectedRows > 0) {
            res.status(200).send({
              status: 200,
              message: "Employee record deleted successfully",
              errorMsg: "",
            });
          } else {
            res.send({
              status: 500,
              message: "",
              errorMsg: "Please enter a valid employee ID ",
            });
          }
        }
      }
    );
  } else {
    res.send({
      status: 422,
      message: "",
      errorMsg: "Only super users can delete employee record!",
    });
  }
});

module.exports = Router;
