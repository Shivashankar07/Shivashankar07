const express = require("express");

const Router = express.Router();

const conn = require("../connection");

Router.get("/", (req, res) => {
  var empId = req.query.id;
  if (!empId) {
    res.send({
      status: 500,
      message: "",
      errorMsg: "Please enter a valid employee ID ",
    });
  }
  conn.query(
    "SELECT * from emp_details WHERE emp_id =" + empId,
    (err, rows, fields) => {
      if (err) {
        console.log(err);
      } else {
        if (rows.length > 0) {
          res.status(200).send({
            status: 200,
            message: "Employee list retrieved successfully",
            empData: rows,
            errorMsg: "",
          });
        } else {
          res.send({
            status: 500,
            message: "",
            empData: rows,
            errorMsg: "Please enter a valid employee ID ",
          });
        }
      }
    }
  );
});

module.exports = Router;
