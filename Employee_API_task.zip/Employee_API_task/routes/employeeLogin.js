const express = require("express");
const Router = express.Router();
const conn = require("../connection");
var validRegex =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

Router.post("/", (req, res) => {
  var empEmail = req.body.email;
  var pwd = req.body.password;
  if (!empEmail || !empEmail.match(validRegex)) {
    res.send({
      status: 422,
      message: "",
      errorMsg: "Please enter a valid email address",
    });
  } else if (!pwd) {
    res.send({
      status: 422,
      message: "",
      errorMsg: "Please enter a valid password",
    });
  }

  conn.query(
    "SELECT * from emp_details WHERE emp_email = '" +
      empEmail +
      "' AND emp_password='" +
      pwd +
      "' ",
    (err, rows, fields) => {
      if (err) {
        throw err;
      } else {
        if (rows.length > 0) {
          conn.query(
            "SELECT * from emp_details WHERE 1",
            (err, rows, fields) => {
              if (!err) {
                res.send({
                  status: 200,
                  message: "Employee logged in successfully",
                  errorMsg: "",
                  employeeList: rows,
                });
              } else {
                throw err;
              }
            }
          );
        } else {
          res.send({
            status: 500,
            message: "",
            errorMsg: "Please enter a valid email and passowrd ",
            employeeList: rows,
          });
        }
      }
    }
  );
});

module.exports = Router;
