const express = require("express");

const Router = express.Router();

const conn = require("../connection");

Router.get("/", (req, res) => {
  conn.query("SELECT * from emp_details WHERE 1 ", (err, rows, fields) => {
    if (err) {
      console.log(err);
    } else {
      res.status(200).send({
        message: "Employee list retrieved successfully",
        empData: rows,
        errorMsg: "",
      });
    }
  });
});

module.exports = Router;
