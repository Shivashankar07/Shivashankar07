const express = require("express");

const Router = express.Router();

const conn = require("../connection");
var moment = require("moment");

// regex validation
var letters = /^[a-zA-Z_ ]*$/;
var validRegex =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

Router.post("/", (req, res) => {
  var isSuperUser = req.body["superUser"];
  var empId = req.body["id"];
  var eName = req.body["Employee_Name"];
  var empEmail = req.body["Email"];
  var pwd = req.body["passowrd"];
  var doj = req.body["DOJ"];
  var updatedOn = getCurrentDateTime();

  var date1 = new Date(doj);
  var doj = moment(date1).format("YYYY-MM-DD");

  // validation part
  if (isSuperUser == 1) {
    if (!empId) {
      res.send({
        status: 422,
        message: "",
        errorMsg: "Invalid employee ID",
      });
    } else if (!eName || !eName.match(letters)) {
      res.send({
        status: 422,
        message: "",
        errorMsg: "Please enter a valid employee name",
      });
    } else if (!empEmail || !empEmail.match(validRegex)) {
      res.send({
        status: 422,
        message: "",
        errorMsg: "Please enter a valid email address",
      });
    } else if (!pwd) {
      res.send({
        status: 422,
        message: "",
        errorMsg: "Please enter a valid password",
      });
    } else if (!doj) {
      res.send({
        status: 422,
        message: "",
        errorMsg: "Please enter a date of join",
      });
    }

    var qry =
      "UPDATE emp_details SET emp_name ='" +
      eName +
      "',emp_email ='" +
      empEmail +
      "', emp_password='" +
      pwd +
      "', emp_doj='" +
      doj +
      "', emp_updatedon ='" +
      updatedOn +
      "' WHERE emp_id =" +
      empId;
    conn.query(qry, (err, rows, fields) => {
      if (err) {
        console.log(err);
      } else {
        res.status(200).send({
          message: "Employee record updated successfully",
          empData: rows,
          errorMsg: "",
        });
      }
    });
  } else {
    res.send({
      status: 422,
      message: "",
      errorMsg: "Only super users can update employee record!",
    });
  }
});

function getCurrentDateTime() {
  var today = new Date();
  var date =
    today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();
  var time =
    today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
  var dateTime = date + " " + time;
  return dateTime;
}

module.exports = Router;
