const express = require("express");
const app = express();
const upload = require("express-fileupload");
const reader = require("xlsx");
const fs = require("fs");
const conn = require("./connection");
var moment = require("moment");

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(upload());

// regex validation
var letters = /^[a-zA-Z_ ]*$/;
var validRegex =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

try {
  app.use("/getEmployeeDetails", require("./routes/getEmployeeDetails"));
} catch (err) {
  console.log(err);
}

try {
  //  app.use("/insertEmployee", require("./routes/insertEmployee"));
  app.post("/insertEmployee", (req, res) => {
    if (req.files) {
      var fileUpd = req.files.fileUpload;
      var filename = fileUpd.name;

      var docCheck = filename.split(".");
      // file format check
      if (docCheck[1] == "csv" || docCheck[1] == "xlsx") {
        fileUpd.mv("./uploads/" + filename, function (err) {
          if (err) {
            res.send("err", err);
          } else {
            // Reading our file
            const file = reader.readFile("./uploads/" + filename, {
              cellDates: true,
            });
            let data = [];
            const sheets = file.SheetNames;
            // reading sheets in excel
            for (let i = 0; i < sheets.length; i++) {
              const temp = reader.utils.sheet_to_json(
                file.Sheets[file.SheetNames[i]]
              );
              temp.forEach((res) => {
                data.push(res);
              });
            }

            fs.unlink("./uploads/" + filename, (err) => {
              if (err) {
                console.log(err);
              }
            });

            // looping through the records and inserting them into DB
            if (data.length > 1) {
              for (var i in data) {
                var eName = data[i]["Employee name"];
                var empEmail = data[i]["Email"];
                var doj = data[i]["Date of join"];

                // date of join - date conversion
                var date1 = new Date(doj);
                var doj = moment(date1).format("YYYY-MM-DD");

                // validation part
                if (!eName || !eName.match(letters)) {
                  res.send({
                    status: 500,
                    message: data[i],
                    errorMsg: "Please enter a valid employee name",
                  });
                } else if (!empEmail || !empEmail.match(validRegex)) {
                  res.send({
                    status: 500,
                    message: "",
                    errorMsg: "Please enter a valid email address",
                  });
                } else if (!doj) {
                  res.send({
                    status: 500,
                    message: "",
                    errorMsg: "Please enter the date of join",
                  });
                } else {
                  // generating random password
                  var pwd = generatePassword(8);
                  // get current datetime
                  var createdOn = getCurrentDateTime();

                  var sql =
                    "INSERT INTO emp_details (emp_id, emp_name, emp_email, emp_doj, emp_password, emp_createdon, emp_updatedon) VALUES ('','" +
                    eName +
                    "','" +
                    empEmail +
                    "','" +
                    doj +
                    "','" +
                    pwd +
                    "','" +
                    createdOn +
                    "','')";
                  conn.query(sql, function (err, result) {
                    if (err) {
                      throw err;
                    } else {
                      console.log("1 record inserted");
                    }
                  });
                }
              }
              res.send({
                status: 200,
                message: "Employee records inserted successfully",
                errorMsg: "",
              });
            } else {
              res.send({
                status: 500,
                message: "",
                errorMsg: "There are no employee data in the document",
              });
            }
          }
        });
      } else {
        res.send({
          status: 500,
          message: "",
          errorMsg: "unsupported file format, please upload csv or excel file",
        });
      }
    } else {
      res.send({
        status: 500,
        message: "",
        errorMsg: "Please upload the document",
      });
    }
  });
} catch (err) {
  res.send({
    status: 500,
    message: "",
    errorMsg: err,
  });
}

function generatePassword(passwordLength) {
  var numberChars = "0123456789";
  var upperChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  var lowerChars = "abcdefghijklmnopqrstuvwxyz";
  var allChars = numberChars + upperChars + lowerChars;
  var randPasswordArray = Array(passwordLength);
  randPasswordArray[0] = numberChars;
  randPasswordArray[1] = upperChars;
  randPasswordArray[2] = lowerChars;
  randPasswordArray = randPasswordArray.fill(allChars, 3);
  return shuffleArray(
    randPasswordArray.map(function (x) {
      return x[Math.floor(Math.random() * x.length)];
    })
  ).join("");
}

function shuffleArray(array) {
  for (var i = array.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
  return array;
}

function getCurrentDateTime() {
  var today = new Date();
  var date =
    today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();
  var time =
    today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
  var dateTime = date + " " + time;
  return dateTime;
}

app.listen("3014", (req, res) => {
  console.log("app started");
});
