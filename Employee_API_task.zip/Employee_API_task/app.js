const express = require("express");
const app = express();
const upload = require("express-fileupload");
const reader = require("xlsx");
const fs = require("fs");
const conn = require("./connection");
var moment = require("moment");

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(upload());

// regex validation
var letters = /^[a-zA-Z_ ]*$/;
var validRegex =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

//  1. List All Inserted Details In a Table View
try {
  app.use("/getEmployeeDetails", require("./routes/getEmployeeDetails"));
} catch (err) {
  res.send({
    status: 500,
    message: "",
    errorMsg: "Error in fetching employee list" + err,
  });
}

// 3, Allow the employee to login and view other employees but don't allow any permissions to employees to modify the records
try {
  app.use("/employeeLogin", require("./routes/employeeLogin"));
} catch (err) {
  res.send({
    status: 500,
    message: "",
    errorMsg: "Error in employee logging in " + err,
  });
}

// 4, Click on row to get the detail page of the record
try {
  app.use("/viewEmployeeInfo", require("./routes/viewEmployeeInfo"));
} catch (err) {
  res.send({
    status: 500,
    message: "",
    errorMsg: "Error in retrieving employee info " + err,
  });
}

// 5, Make a delete Functionality for the record (only for super user)
try {
  app.use("/deleteEmployee", require("./routes/deleteEmployee"));
} catch (err) {
  res.send({
    status: 500,
    message: "",
    errorMsg: "Error in deleting employee info " + err,
  });
}

// 6, Make a update Functionality for the record (only for super user)
try {
  app.use("/updateEmployeeInfo", require("./routes/updateEmployeeInfo"));
} catch (err) {
  res.send({
    status: 500,
    message: "",
    errorMsg: "Error in updating employee info " + err,
  });
}

// 2, While inserting create an account for each employee with username as email and randome generated password and send those credentials via email to employee
try {
  //  app.use("/insertEmployee", require("./routes/insertEmployee"));
  app.post("/insertEmployee", (req, res) => {
    if (req.files) {
      var fileUpd = req.files.fileUpload;
      var filename = fileUpd.name;

      var docCheck = filename.split(".");
      // file format check
      if (docCheck[1] == "csv" || docCheck[1] == "xlsx") {
        fileUpd.mv("./uploads/" + filename, function (err) {
          if (err) {
            res.send("err", err);
          } else {
            // Reading our file
            const file = reader.readFile("./uploads/" + filename, {
              cellDates: true,
            });
            let data = [];
            const sheets = file.SheetNames;
            // reading sheets in excel
            for (let i = 0; i < sheets.length; i++) {
              const temp = reader.utils.sheet_to_json(
                file.Sheets[file.SheetNames[i]]
              );
              temp.forEach((res) => {
                data.push(res);
              });
            }

            fs.unlink("./uploads/" + filename, (err) => {
              if (err) {
                console.log(err);
              }
            });

            // looping through the records and inserting them into DB
            if (data.length > 1) {
              for (var i in data) {
                var eName = data[i]["Employee name"];
                var empEmail = data[i]["Email"];
                var doj = data[i]["Date of join"];

                // date of join - date conversion
                var date1 = new Date(doj);
                var doj = moment(date1).format("YYYY-MM-DD");

                // validation part
                if (!eName || !eName.match(letters)) {
                  res.send({
                    status: 422,
                    message: data[i],
                    errorMsg: "Please enter a valid employee name",
                  });
                } else if (!empEmail || !empEmail.match(validRegex)) {
                  res.send({
                    status: 422,
                    message: "",
                    errorMsg: "Please enter a valid email address",
                  });
                } else if (!doj) {
                  res.send({
                    status: 422,
                    message: "",
                    errorMsg: "Please enter the date of join",
                  });
                } else {
                  // generating random password
                  var pwd = generatePassword(8);
                  // get current datetime
                  var createdOn = getCurrentDateTime();

                  var sql =
                    "INSERT INTO emp_details (emp_id, emp_name, emp_email, emp_doj, emp_password, emp_createdon, emp_updatedon) VALUES ('','" +
                    eName +
                    "','" +
                    empEmail +
                    "','" +
                    doj +
                    "','" +
                    pwd +
                    "','" +
                    createdOn +
                    "','')";
                  conn.query(sql, function (err, result) {
                    if (err) {
                      throw err;
                    } else {
                      console.log(" record inserted");
                    }
                  });

                  sendMail(empEmail, eName, pwd);
                }
              }
              res.send({
                status: 201,
                message: "Employee records inserted successfully",
                errorMsg: "",
              });
            } else {
              res.send({
                status: 422,
                message: "",
                errorMsg: "There are no employee data in the document",
              });
            }
          }
        });
      } else {
        res.send({
          status: 422,
          message: "",
          errorMsg: "unsupported file format, please upload csv or excel file",
        });
      }
    } else {
      res.send({
        status: 422,
        message: "",
        errorMsg: "Please upload the document",
      });
    }
  });
} catch (err) {
  res.send({
    status: 500,
    message: "",
    errorMsg: err,
  });
}

function generatePassword(passwordLength) {
  var numberChars = "0123456789";
  var upperChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  var lowerChars = "abcdefghijklmnopqrstuvwxyz";
  var allChars = numberChars + upperChars + lowerChars;
  var randPasswordArray = Array(passwordLength);
  randPasswordArray[0] = numberChars;
  randPasswordArray[1] = upperChars;
  randPasswordArray[2] = lowerChars;
  randPasswordArray = randPasswordArray.fill(allChars, 3);
  return shuffleArray(
    randPasswordArray.map(function (x) {
      return x[Math.floor(Math.random() * x.length)];
    })
  ).join("");
}

function shuffleArray(array) {
  for (var i = array.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
  return array;
}

function getCurrentDateTime() {
  var today = new Date();
  var date =
    today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();
  var time =
    today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
  var dateTime = date + " " + time;
  return dateTime;
}

function sendMail(empEmail, empName, password) {
  var nodemailer = require("nodemailer");

  var transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: "username@gmail.com",
      pass: "password",
    },
  });

  var mailOptions = {
    from: "username@gmail.com",
    to: empEmail,
    subject: "New Employee Account Created",
    html:
      "<h1>Welcome " +
      empName +
      ",</h1><p>New employee account created</p><p>Email - " +
      empEmail +
      "</p><p>Password - " +
      password +
      "</p><br/>Thanks!",
  };

  transporter.sendMail(mailOptions, function (error, info) {
    if (error) {
      console.log(error);
    } else {
      console.log("Email sent: " + info.response);
    }
  });
}

app.listen("3014", (req, res) => {
  console.log("app started");
});
